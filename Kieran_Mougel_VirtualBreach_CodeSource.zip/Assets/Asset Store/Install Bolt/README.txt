Thank you for choosing Bolt!

To get started, import the package that matches your project's scripting runtime version (.NET 3 or 4).

If you're not sure, use [ Tools > Install Bolt ].

You can safely delete the "Bolt Install" folder after importing the package.